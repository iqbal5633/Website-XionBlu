document.addEventListener('DOMContentLoaded', () => {
    // Navbar Sticky
    const navbar = document.getElementById('mainNav');
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('sticky', window.scrollY > 50);
    });

    // Menu Mobile
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        menuToggle.innerHTML = navMenu.classList.contains('active') 
            ? '<i class="fa-solid fa-xmark"></i>' 
            : '<i class="fa-solid fa-bars"></i>';
    });

    // Tutup menu saat link diklik
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
        });
    });

    // Popup Pembayaran
    const popup = document.getElementById('popupBayar');
    const btnBeli = document.querySelectorAll('.btn-buy');
    const btnTutup = document.getElementById('tutupPopup');

    // Buka Popup
    btnBeli.forEach(btn => {
        btn.addEventListener('click', () => {
            popup.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    // Tutup Popup
    function tutupPopup() {
        popup.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    btnTutup.addEventListener('click', tutupPopup);
    popup.addEventListener('click', (e) => e.target === popup && tutupPopup());
    document.addEventListener('keydown', (e) => e.key === 'Escape' && tutupPopup());
});
