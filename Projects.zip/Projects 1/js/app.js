document.addEventListener('DOMContentLoaded', () => {
    // ==========================================
    // FUNGSI BANTU PENYIMPANAN DATA
    // ==========================================
    const DB = {
        ambilSemua: () => JSON.parse(localStorage.getItem('xionblu_data_akun')) || [],
        simpanSemua: (data) => localStorage.setItem('xionblu_data_akun', JSON.stringify(data)),
        aktifkanUser: (user) => localStorage.setItem('xionblu_active_user', JSON.stringify(user)),
        ambilUserAktif: () => JSON.parse(localStorage.getItem('xionblu_active_user')),
        hapusUserAktif: () => localStorage.removeItem('xionblu_active_user')
    };

    // ==========================================
    // HALAMAN LOGIN
    // ==========================================
    if (document.getElementById('formLogin')) {
        // Cek kalau sudah login
        if (DB.ambilUserAktif()) window.location.href = 'dashboard.html';

        // Tampil/Sembunyi Password
        document.getElementById('toggleLogin').addEventListener('click', function() {
            const inp = document.getElementById('loginPass');
            inp.type = inp.type === 'password' ? 'text' : 'password';
            this.innerHTML = inp.type === 'password' ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
        });

        // Proses Login
        const form = document.getElementById('formLogin');
        const alertBox = document.getElementById('alertLogin');

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const id = document.getElementById('loginUser').value.trim().toLowerCase();
            const pass = document.getElementById('loginPass').value;
            const daftarAkun = DB.ambilSemua();

            const ketemu = daftarAkun.find(akun => 
                (akun.username === id || akun.email === id) && akun.password === pass
            );

            if (ketemu) {
                DB.aktifkanUser(ketemu);
                alertBox.className = 'alert-box success';
                alertBox.textContent = '✅ Berhasil masuk! Mengalihkan...';
                setTimeout(() => window.location.href = 'dashboard.html', 1000);
            } else {
                alertBox.className = 'alert-box error';
                alertBox.textContent = '❌ Username/Email atau Sandi salah!';
            }
        });
    }

    // ==========================================
    // HALAMAN DAFTAR
    // ==========================================
    if (document.getElementById('formDaftar')) {
        if (DB.ambilUserAktif()) window.location.href = 'dashboard.html';

        // Tampil/Sembunyi Password
        document.querySelectorAll('.eye-toggle').forEach(tombol => {
            tombol.addEventListener('click', function() {
                const inp = this.parentElement.querySelector('input');
                inp.type = inp.type === 'password' ? 'text' : 'password';
                this.innerHTML = inp.type === 'password' ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
            });
        });

        // Proses Daftar
        const form = document.getElementById('formDaftar');
        const alertBox = document.getElementById('alertDaftar');

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const user = document.getElementById('regUser').value.trim().toLowerCase();
            const email = document.getElementById('regEmail').value.trim().toLowerCase();
            const hp = document.getElementById('regHp').value.trim();
            const pass1 = document.getElementById('regPass').value;
            const pass2 = document.getElementById('regPass2').value;
            const daftarAkun = DB.ambilSemua();

            // Validasi
            if (pass1 !== pass2) return pesan('❌ Sandi tidak cocok!', 'error');
            if (pass1.length < 6) return pesan('❌ Sandi minimal 6 karakter!', 'error');
            if (daftarAkun.some(a => a.username === user)) return pesan('❌ Username sudah dipakai!', 'error');
            if (daftarAkun.some(a => a.email === email)) return pesan('❌ Email sudah terdaftar!', 'error');

            // Simpan akun baru
            const akunBaru = {
                id: Date.now(),
                username: user,
                email: email,
                hp: hp,
                password: pass1,
                saldo: 0,
                tanggalDaftar: new Date().toLocaleString('id-ID')
            };

            daftarAkun.push(akunBaru);
            DB.simpanSemua(daftarAkun);
            pesan('✅ Pendaftaran berhasil! Mengalihkan ke login...', 'success');
            
            setTimeout(() => window.location.href = 'login.html', 1500);
        });

        function pesan(teks, tipe) {
            alertBox.className = `alert-box ${tipe}`;
            alertBox.textContent = teks;
        }
    }

    // ==========================================
    // HALAMAN DASHBOARD
    // ==========================================
    if (document.getElementById('namaUser')) {
        // Proteksi: Harus Login
        const userAktif = DB.ambilUserAktif();
        if (!userAktif) {
            alert('⚠️ Silakan login terlebih dahulu!');
            window.location.href = 'login.html';
            return;
        }

        // Tampilkan Data Akun (Berbeda tiap user)
        document.getElementById('namaUser').textContent = userAktif.username;
        document.getElementById('infoUsername').textContent = userAktif.username;
        document.getElementById('infoSaldo').textContent = `Rp ${userAktif.saldo.toLocaleString('id-ID')}`;

        // FITUR LOGOUT BERFUNGSI 100%
        document.getElementById('btnLogout').addEventListener('click', (e) => {
            e.preventDefault();
            if(confirm('Yakin ingin keluar dari akun?')) {
                DB.hapusUserAktif();
                window.location.href = 'login.html';
            }
        });
    }
});
